---
name: Organic Glassmorphic Enterprise
colors:
  surface: '#f9faf7'
  surface-dim: '#d9dad8'
  surface-bright: '#f9faf7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f1'
  surface-container: '#edeeeb'
  surface-container-high: '#e7e8e6'
  surface-container-highest: '#e2e3e0'
  on-surface: '#191c1b'
  on-surface-variant: '#444843'
  inverse-surface: '#2e312f'
  inverse-on-surface: '#f0f1ee'
  outline: '#747873'
  outline-variant: '#c4c7c1'
  surface-tint: '#586158'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#151d16'
  on-primary-container: '#7d867c'
  inverse-primary: '#c0c9be'
  secondary: '#2c6290'
  on-secondary: '#ffffff'
  secondary-container: '#99cbff'
  on-secondary-container: '#1c5683'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002202'
  on-tertiary-container: '#42953f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce5d9'
  primary-fixed-dim: '#c0c9be'
  on-primary-fixed: '#151d16'
  on-primary-fixed-variant: '#404940'
  secondary-fixed: '#cfe5ff'
  secondary-fixed-dim: '#99cbff'
  on-secondary-fixed: '#001d34'
  on-secondary-fixed-variant: '#064a77'
  tertiary-fixed: '#a0f795'
  tertiary-fixed-dim: '#85da7b'
  on-tertiary-fixed: '#002202'
  on-tertiary-fixed-variant: '#00530d'
  background: '#f9faf7'
  on-background: '#191c1b'
  surface-variant: '#e2e3e0'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.02em
  stat-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '600'
    lineHeight: '1.05'
    letterSpacing: -0.035em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: 0em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.04em
  label-badge:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: 0.01em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.25rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 2.5rem
  space-3xl: 3.5rem
---

## Brand & Style

This design system expresses an ultra-premium, serene, and organic financial technology aesthetic. Moving away from cold corporate fintech cliches, it pairs soft natural depth with precision enterprise compliance tooling.

- **Brand Personality**: Calm, authoritative, sophisticated, breathable, and effortlessly lucid. It reframes complex regional tax, compliance, and enterprise payroll mandates into welcoming, high-clarity workspaces.
- **Design Style**: Ultra-premium soft organic glassmorphism. It uses warm bone-white translucent planes layered atop softly blurred botanical backdrops, punctuated by high-contrast dark forest charcoal islands, airy sky-blue metric highlights, and vibrant ambient gradients.
- **Target Audience**: Modern enterprise founders, CFOs, operations directors, and compliance leaders across high-growth international hubs who demand institutional rigor delivered with editorial elegance.

## Colors

The color architecture is built upon subtle warm organic surfaces contrasted against deep botanical charcoals and calibrated functional accents.

- **Primary Canvas & Glass Containers**: The root backdrop is a warm bone neutral `#FAFBF8` layered over blurred natural photography (`backdrop-filter: blur(48px)`). Card surfaces utilize high-translucency milk fills (`rgba(250, 251, 248, 0.82)`) bound by an ethereal perimeter stroke (`#E8EDE6` or `rgba(232, 237, 230, 0.65)`).
- **Primary Ink & High-Contrast Anchors**: `#141C15` (Deep Midnight Charcoal-Olive) is used for maximum contrast typography, hero status widgets, and grounded telemetry cards.
- **Sky Accent Surfaces**: `#97C9FD` blending gently into `#B4D7FE` and `#EAF4FF` provides an airy, luminous plane for standout performance KPIs, Saudization scores, and primary metrics.
- **Signature Gradient Action**: Key primary CTA buttons leverage an organic linear blend running horizontally from fresh pastel lime (`#8DE383` / `#93E97D`) to warm sunlit amber-orange (`#F6BD60` / `#ECA74E`).
- **Telemetry & Status Indicators**:
  - Positive / On-Track: `#8DE383` (Lime) and `#2D6A28` (Forest Leaf).
  - Approaching Deadline / Warning: `#F6BD60` (Warm Amber).
  - Urgent / Overdue / Rejected: `#FA6E59` (Coral Tangerine).

## Typography

The typography is powered entirely by **Plus Jakarta Sans**, tuned for extreme crispness across numerical density and editorial headings.

- **Headings & Salutations**: Fluid, high-personality weights (`600`) featuring tight letter-spacing (`-0.02em` to `-0.03em`) to anchor greetings and corporate identities with human warmth.
- **Metric Displays (`stat-xl`)**: Monospace-like optical balance with natural humanist curves. Numbers are presented with high clarity, ensuring instant legibility on soft pastel and midnight surfaces.
- **Micro-Copy & Telemetry**: Labels and status chips utilize subtle positive tracking (`+0.01em` to `+0.04em`) at `0.75rem` and `0.8125rem` sizes, retaining razor-sharp definition against glass and dark container fills.

## Layout & Spacing

The layout model is organized around floating content panels positioned over an ambient environmental backdrop.

- **Grid Architecture**:
  - **Desktop**: A persistent floating vertical navigation dock (260px fixed width) paired with a responsive 12-column adaptive widget grid (`gutter-desktop: 1.75rem`, `margin-desktop: 2.25rem`).
  - **Tablet**: A collapsed sidebar icon rail (72px) with an 8-column layout (`gutter: 1.25rem`, `margin: 1.5rem`).
  - **Mobile**: A single-column vertical stack with full-width swipeable cards and fixed bottom micro-nav dock (`gutter: 1rem`, `margin: 1rem`).
- **Internal Card Padding**: Primary content cards feature generous, breathable internal air (`space-lg` to `space-xl` / 24px - 32px), creating high visual calm despite heavy compliance data density.

## Elevation & Depth

Visual hierarchy is achieved through physical glass diffusion, tinted multi-layered ambient drop shadows, and delicate 1px boundary lines rather than heavy drop shadows.

- **Primary Frosted Panels**:
  - Surface: `rgba(250, 251, 248, 0.84)`.
  - Backdrop Filter: `blur(40px) saturate(140%)`.
  - Border: `1px solid rgba(232, 237, 230, 0.7)`.
  - Shadow: Multi-tier ambient drop `0 12px 36px -4px rgba(20, 28, 21, 0.04), 0 2px 8px 0 rgba(20, 28, 21, 0.02)`.
- **Sky-Blue Accent Cards**:
  - Surface: Linear gradient `180deg, #B5D8FE 0%, #90C5FD 100%`.
  - Border: `1px solid rgba(255, 255, 255, 0.5)`.
  - Shadow: `0 16px 40px -8px rgba(144, 197, 253, 0.35)`.
- **Midnight Status Widgets**:
  - Surface: `rgba(20, 28, 21, 0.94)`.
  - Border: `1px solid rgba(255, 255, 255, 0.08)`.
  - Shadow: `0 16px 32px -6px rgba(0, 0, 0, 0.25)`.

## Shapes

The shape vocabulary uses exaggerated, organic curves that echo natural river stones and tactile frosted acrylic.

- **Base Cards & Main Containers**: Soft large radiuses ranging from `28px` to `36px` (`rounded-xl` to custom `rounded-[32px]`).
- **Pill Controls & Interactive Surfaces**: Strict `rounded-full` (9999px) treatment for primary action buttons, navigation indicator capsules, and metric tags.
- **Nested Inner Modules & Micro-Chips**: `rounded-lg` (16px to 20px) to mirror outer parent geometry while preserving proportional hierarchy.

## Components

### 1. Primary Action Button
- **Geometry**: Pill radius (`rounded-full`), height: 48px, horizontal padding: `1.75rem`.
- **Fill**: Smooth linear gradient `90deg, #8DE383 0%, #F6BD60 100%`.
- **Typography**: `Plus Jakarta Sans`, 14px, Weight 600, Color `#141C15`.
- **Iconography**: Inline left-aligned `+` or action icon in `#141C15` with 16px size.
- **Hover/Active**: Subtly expand spread (`scale(1.015)`) with an ambient colored glow (`box-shadow: 0 8px 24px -4px rgba(246, 189, 96, 0.4)`).

### 2. Information Cards
- **Soft Cream Card**: `rgba(250, 251, 248, 0.82)` glass panel, 32px border radius, 1px border in `#E8EDE6`. Houses data graphs, task lists, and general activity feeds.
- **Sky-Blue KPI Hero Card**: Soft sky gradient (`#B4D7FE` to `#97C9FD`), 32px border radius. Displays dark bold numeric metrics (`stat-xl` in `#141C15`), status subtext ("High green"), and pill status pills.
- **Dark Roadmap Card**: `#141C15` charcoal-olive background, 32px border radius, subtle interior green glow, tracking progress milestones with connected green dots (`#8DE383`) and white timeline nodes.

### 3. Chips & Status Badges
- **Nitaqat & Compliance Badges**: Pill-shaped capsule with translucent fill (`rgba(141, 227, 131, 0.2)` on sky/light, or `rgba(255, 255, 255, 0.08)` on dark). Contains a 6px solid circular colored dot (`#8DE383` green or `#FA6E59` coral) followed by 12px medium weight text.
- **Deadline Tag**: Soft warm peach-red capsule (`rgba(250, 110, 89, 0.12)`) with a 5px `#FA6E59` pulse dot and text "11 days left".

### 4. Progress Sliders & Trackers
- **Track**: 4px height, soft neutral bone-gray (`rgba(20, 28, 21, 0.08)`).
- **Fill**: `#2D6A28` to `#8DE383` forest-to-lime gradient.
- **Thumb / Indicator**: 8px circular pill in `#FFFFFF` with 1px border `#2D6A28` and subtle drop shadow.

### 5. Floating Navigation Rail
- **Container**: Elevated glass capsule sidebar running along the left edge, frosted with `backdrop-filter: blur(32px)`.
- **Active Navigation Item**: `#EBF0E9` or solid white pill container with soft shadow, `#141C15` bold text, and integrated count badges.
- **Inactive Items**: Subtle `#667065` muted icon and label, transitioning to primary dark on hover.