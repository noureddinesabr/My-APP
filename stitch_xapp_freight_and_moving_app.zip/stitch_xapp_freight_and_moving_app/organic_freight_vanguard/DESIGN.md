---
name: Organic Freight Vanguard
colors:
  surface: '#eaffe9'
  surface-dim: '#cae0c9'
  surface-bright: '#eaffe9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e3fae2'
  surface-container: '#ddf4dd'
  surface-container-high: '#d8eed7'
  surface-container-highest: '#d2e8d2'
  on-surface: '#0d1f11'
  on-surface-variant: '#42493d'
  inverse-surface: '#223525'
  inverse-on-surface: '#e0f7e0'
  outline: '#72796c'
  outline-variant: '#c2c9ba'
  surface-tint: '#3b692b'
  primary: '#154207'
  on-primary: '#ffffff'
  primary-container: '#2d5a1e'
  on-primary-container: '#9cd086'
  inverse-primary: '#a0d48a'
  secondary: '#3f6a00'
  on-secondary: '#ffffff'
  secondary-container: '#aef35e'
  on-secondary-container: '#426e00'
  tertiary: '#612800'
  on-tertiary: '#ffffff'
  tertiary-container: '#853a00'
  on-tertiary-container: '#ffb185'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bcf1a4'
  primary-fixed-dim: '#a0d48a'
  on-primary-fixed: '#042100'
  on-primary-fixed-variant: '#245015'
  secondary-fixed: '#b1f661'
  secondary-fixed-dim: '#96d947'
  on-secondary-fixed: '#0f2000'
  on-secondary-fixed-variant: '#2e4f00'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb68e'
  on-tertiary-fixed: '#331200'
  on-tertiary-fixed-variant: '#763300'
  background: '#eaffe9'
  on-background: '#0d1f11'
  surface-variant: '#d2e8d2'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an earthy, dependable, and tactile aesthetic tailored for logistical operations, cross-country freight, and residential relocation in Morocco. The interface blends modern utility with regional resonance: warm natural surfaces evoke chalked stone, olive groves, and architectural clay, abandoning the clinical blue-gray aesthetic common in enterprise freight platforms. 

The emotional delivery balances unyielding infrastructural reliability with approachable human touch. Moving home and booking long-haul freight can be stressful high-stakes transactions; the UI responds with calming mineral backgrounds, clear spatial hierarchy, and high-legibility touchpoints.

### Aesthetic Framework
- **Warm Organic Functionalism:** Rooted in organic modernism, relying on creamy linen-like backdrops, tactile forest tones, and desert ochre callouts.
- **Translucent Depth & Crisp Geometry:** Structured container cards rendered in stark white frosted overlays, framed with crisp organic borders to counter high ambient Mediterranean sunlight without glare.
- **Tactile Ergonomics:** Interactive targets feature full pill contours (`rounded-full`), generous tap targets suited for one-handed operation on the road, and unambiguous status differentiation.

## Colors

The palette mirrors natural Moroccan flora, architectural minerals, and rich earthen accents. All token selections prioritize AAA/AA contrast against the light mineral backdrops under bright outdoor conditions.

### Complete Color Role Mapping
- **Primary (`#2D5A1E` / `#386A1B`):** Deep Moroccan Olive Green. Applied to core affirmative actions, primary pill buttons, driver confirmation sequences, and brand focal anchors.
  - `on-primary`: `#FFFFFF`
  - `primary-container`: `#E1F2D5`
  - `on-primary-container`: `#0C2005`
- **Secondary / Accent (`#65A30D` / `#84CC16`):** Vibrant Cedar Lime. Applied to real-time status pulses, verified shipment markers, dynamic map routes, and completed telemetry indicators.
  - `on-secondary`: `#FFFFFF`
  - `secondary-container`: `#EBF7CF`
  - `on-secondary-container`: `#1D3700`
- **Tertiary (`#B45309` / `#D97706`):** Moroccan Sand Ochre. Applied to priority dispatch tags, heavy-cargo advisories, escrow moving deposits, and urgent tracking alerts.
  - `on-tertiary`: `#FFFFFF`
  - `tertiary-container`: `#FFDDB8`
  - `on-tertiary-container`: `#2B1700`
- **Surface & Backgrounds:**
  - `background`: `#F7F9F6` (Warm Calcareous Stone)
  - `surface`: `#F7F9F6`
  - `surface-container-lowest`: `#FFFFFF` (Card surfaces & modals)
  - `surface-container-low`: `#F0F4EF` (Recessed backplates & data groups)
  - `surface-container`: `#EAEFE8`
  - `surface-container-high`: `#E2E8DF` (Dividers, borders, and input strokes)
  - `surface-container-highest`: `#D7DFD4`
- **Typography & Content:**
  - `on-surface`: `#111C12` (Deep Charcoal Green for maximum clarity)
  - `on-surface-variant`: `#526654` (Muted Sage for secondary metadata and icons)
  - `outline`: `#E2E8DF`
  - `outline-variant`: `#CED7CB`

## Typography

The design system exclusively utilizes **Plus Jakarta Sans** across all breakpoints. Its geometric precision combined with organic humanist apertures provides high legibility for alphanumeric cargo plates, bilingual addresses (French / Moroccan Arabic transcriptions), and dense shipping manifests.

### Rules of Usage
- **Numerics & Telemetry:** Pricing (`MAD`), cargo dimensions (`m³`, `kg`), and ETAs utilize `title-lg` or `headline-md` with `font-weight: 700` to preserve immediate scannability on dashboard cards.
- **Tracking & Line Height:** Negative letter tracking is strictly reserved for sizes 24px and above to produce cohesive display headers. Small-scale data (`label-sm`, `label-md`) expands tracking to maintain crisp character separation on low-ppi handheld displays.
- **Hierarchy Stacking:** Pair `label-md` uppercase tokens in `on-surface-variant` with `headline-sm` or `title-md` in `on-surface` for operational metric modules (e.g., origin, destination, cargo weight).

## Layout & Spacing

The layout model implements a fluid grid system driven by an 8pt architectural rhythm, with 4pt subdivisions for micro-alignments inside interactive controls.

### Grid Architecture & Breakpoints
- **Mobile (< 600px):** 4-column fluid grid, `16px` (`1rem`) outer margins, `16px` gutters. Single-column stacked cards for manifests, vehicle types, and booking flows.
- **Tablet (600px - 1023px):** 8-column fluid grid, `32px` (`2rem`) outer margins, `24px` (`1.5rem`) gutters. Split-screen layout paired between map viewports and booking manifests.
- **Desktop (≥ 1024px):** 12-column fixed-max grid centered at `1280px`, `48px` (`3rem`) outer margins, `32px` (`2rem`) gutters. Multi-column dispatcher dashboards with persistent collateral filters.

### Spacing Application
- `space-xs` (4px): Inner badge padding, icon-to-label inline gaps.
- `space-sm` (8px): Input internal vertical padding, chip spacing, stacked metadata rows.
- `space-md` (16px): Card standard internal padding, button inline padding, standard form gap.
- `space-lg` (24px): Card-to-card structural vertical flow, section separation within drawers.
- `space-xl` (40px): Page-level module separation and major checkout milestone zones.

## Elevation & Depth

Visual hierarchy combines pure frosted white surfaces, micro-borders, and ambient olive-tinted drop shadows. Heavy stark black drop shadows are avoided in favor of warm, sunlight-tempered ambient occlusion.

### Elevation Levels
- **Level 0 (Flat / Canvas):** Surface color `#F7F9F6`. Used for underlying page canvases and non-interactive backgrounds.
- **Level 1 (Frosted Cards & Lists):** Surface `#FFFFFF` at 92% opacity with backdrop blur (`backdrop-filter: blur(12px)`). Encased in a `1px` structural border of `#E2E8DF`. Shadow: `0 2px 8px -2px rgba(17, 28, 18, 0.04), 0 1px 3px 0 rgba(17, 28, 18, 0.02)`.
- **Level 2 (Hovered Cards & Interactive Controls):** Surface `#FFFFFF`. Shadow: `0 8px 16px -4px rgba(45, 90, 30, 0.06), 0 2px 6px -1px rgba(17, 28, 18, 0.04)`. Border: `#CED7CB`.
- **Level 3 (Floating Action Bars & Drawers):** Bottom action sheets, quote drawers, and active route waypoints. Shadow: `0 16px 32px -8px rgba(17, 28, 18, 0.08), 0 4px 12px -2px rgba(17, 28, 18, 0.03)`.
- **Level 4 (Modals & Urgent Overlays):** Surface `#FFFFFF`. Shadow: `0 24px 48px -12px rgba(17, 28, 18, 0.14)`. Backdrop dimmed with `#111C12` at 40% opacity.

## Shapes

The design system adopts a **Pill-shaped (Level 3)** signature geometry. Interactive components employ full pill radii (`9999px` / `rounded-full`), while content containers, manifests, and cards utilize balanced structural curvature (`rounded-2xl` / `16px` to `24px`) to establish friendly yet disciplined packaging.

### Geometry Hierarchy
- **Pill (`rounded-full` / `9999px`):** Primary buttons, secondary buttons, status badges, vehicle category chips, filter tags, and user avatars.
- **Card Large (`24px` / `1.5rem`):** Freight tracking summary cards, quote overview panels, map preview sheets.
- **Container Medium (`16px` / `1rem`):** Text input containers, driver profile summary tiles, address picker nodes.
- **Container Small (`8px` / `0.5rem`):** Checkbox elements, progress trackers, map marker labels.

## Components

### Buttons
- **Primary Pill:** Background `#2D5A1E`, foreground `#FFFFFF`, height `52px` on mobile for thumb reach (`44px` on desktop). Border radius `9999px`. Subtle interactive hover shifts background to `#386A1B`. Active states introduce scale transform `scale(0.98)`.
- **Secondary Pill:** Background `#FFFFFF`, foreground `#2D5A1E`, border `1.5px solid #2D5A1E`. Hover background `#F0F4EF`.
- **Accent Highlight Action:** Background `#65A30D`, foreground `#FFFFFF`, applied to immediate dispatch and instant bid approvals.

### Chips & Badges
- **Status Badges:** Small pill contours (`rounded-full`), internal padding `4px 12px`.
  - *Standard Dispatch:* Background `#E1F2D5`, text `#2D5A1E`, `label-sm`.
  - *Express / Urgent Moving:* Background `#FFDDB8`, text `#B45309`, `label-sm` with optional animated ochre dot indicator.
  - *Active Route / Live:* Background `#EBF7CF`, text `#1D3700`, with leading `#65A30D` pulse dot.
- **Filter Chips:** Frosted white (`#FFFFFF`) with `1px solid #E2E8DF`. When active: `#2D5A1E` background with `#FFFFFF` text.

### Cards & Manifest Modules
- Rendered in solid white frosted layers `#FFFFFF` with `1px solid #E2E8DF`.
- Internal padding is strictly `20px` (`1.25rem`) for compact viewports and `24px` (`1.5rem`) for desktop.
- Header, route nodes, and cargo summaries are delineated by light separator strokes (`#F0F4EF`) rather than heavy horizontal rules.

### Input Fields
- Enclosed pill or rounded container (`16px` radius).
- Background `#FFFFFF`, border `1px solid #E2E8DF`, text `#111C12`. Placeholder text set in `#526654` at 70% opacity.
- Focus state: border `2px solid #2D5A1E`, zero outline halo, retaining organic cleanliness.

### Checkboxes & Radios
- Radios: `20px` diameter, border `#CED7CB`. Selected: outer ring `#2D5A1E`, inner dot `#2D5A1E` with `#FFFFFF` spacing.
- Checkboxes: `20px` with `6px` radius. Active state filled with `#2D5A1E`, white tick icon.

### Route & Cargo Waypoints (Domain Component)
- Distinctive vertical trail visualizing inter-city routes (e.g., Casablanca → Marrakech).
- Origin node: hollow circle with `#2D5A1E` ring.
- Path: dashed `2px` line colored in `#CED7CB`.
- Destination node: solid `#65A30D` map pin icon.