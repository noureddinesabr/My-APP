---
name: Atlas Freight Glass
colors:
  surface: '#08160a'
  surface-dim: '#08160a'
  surface-bright: '#2d3d2e'
  surface-container-lowest: '#041106'
  surface-container-low: '#101f12'
  surface-container: '#142316'
  surface-container-high: '#1e2e20'
  surface-container-highest: '#29392a'
  on-surface: '#d5e8d3'
  on-surface-variant: '#c2cab0'
  inverse-surface: '#d5e8d3'
  inverse-on-surface: '#253426'
  outline: '#8c947c'
  outline-variant: '#424936'
  surface-tint: '#98da27'
  primary: '#ccff80'
  on-primary: '#213600'
  primary-container: '#a3e635'
  on-primary-container: '#416400'
  inverse-primary: '#446900'
  secondary: '#b5cdb3'
  on-secondary: '#213522'
  secondary-container: '#394e3a'
  on-secondary-container: '#a7bfa5'
  tertiary: '#ffecd9'
  on-tertiary: '#472a00'
  tertiary-container: '#ffc989'
  on-tertiary-container: '#805000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b2f746'
  primary-fixed-dim: '#98da27'
  on-primary-fixed: '#121f00'
  on-primary-fixed-variant: '#334f00'
  secondary-fixed: '#d0e9ce'
  secondary-fixed-dim: '#b5cdb3'
  on-secondary-fixed: '#0c200f'
  on-secondary-fixed-variant: '#374c38'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#08160a'
  on-background: '#d5e8d3'
  surface-variant: '#29392a'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 2.5rem
  space-3xl: 3rem
---

## Brand & Style

This design system establishes an ultra-modern, organic-industrial aesthetic crafted specifically for on-demand logistics, moving, and freight transport across Morocco (Casablanca, Marrakech, Tangier, Rabat, Agadir). It blends the raw utility of road logistics with serene, high-end organic tones inspired by Atlas mountain pines, argan foliage, and cedar groves.

### Design Movement: Organic Frosted Glassmorphism
The UI balances deep, protective botanical greens with high-energy neon chartreuse accents and sunlit Moroccan amber warmth:
- **Tone:** Authoritative, lightning-fast, dependable, tactile, and frictionless.
- **Visual Tenets:** Heavy atmospheric depth, translucent floating sheet glass (`backdrop-filter: blur(24px)`), hairline inner glass borders (`rgba(255, 255, 255, 0.12)`), pill-shaped interactive elements, and pillowy 24px–32px corner radii.
- **Cultural Adaptability:** Supports rapid contextual switching between French, Moroccan Darija, and Standard Arabic (RTL ready), with specialized high-legibility treatment for currency counters in Moroccan Dirham (`MAD` / `د.م.`).

## Colors

The color architecture is rooted in deep evergreen foliage combined with vibrant electric luminescent pigments to maximize outdoor visibility for truck operators in bright sunlight while delivering a cozy, opulent glass aesthetic at night.

### Color Rules & Application
- **Primary (`#A3E635` / `#3B6911`):** Electric chartreuse lime. Reserved strictly for primary call-to-actions, live trip tracking telemetry, selected vehicle categories (e.g., Honda 330, Pickup, 3.5T, Semi-trailer), and dynamic progress rings.
- **Secondary & Containers (`#1A2E1C`, `#233D27`):** The foundational substrate of the dark mode glass panels. Creates ambient depth without ever using desaturated greys or pitch blacks.
- **Tertiary Accent (`#F6D882` / `#F59E0B`):** Warm Moroccan honey and Sahara sand tones. Applied exclusively to transit status tags ("En transit", "Chargement"), price breakdowns in MAD, driver rating star clusters, and urgent cargo alerts.
- **Glass Transparency Formulas:**
  - Card Glass Fill: `rgba(26, 46, 28, 0.72)` in dark mode with `backdrop-filter: blur(28px)`.
  - Ambient Glass Rim: `1px solid rgba(163, 230, 53, 0.15)` along top and side edges; `rgba(255, 255, 255, 0.06)` along bottom edges.

## Typography

The typographic hierarchy pairs **Plus Jakarta Sans** for expressive, geometric headers, navigation chips, and numerical KPI readouts with **Inter** for bulletproof body and data-dense route manifests.

### Numerical and Currency Formatting
- For metrics, mileage counters (e.g. `240 KM`), estimated arrival times, and monetary quotes (e.g. `1,850 MAD`), apply `font-feature-settings: "cv02", "cv03", "cv04", "tnum"` to maintain tabular alignment on moving dashboard cards.
- Line heights are intentionally generous to accommodate multilingual strings where French and Arabic text require larger vertical breathing room than standard English.

## Layout & Spacing

The layout is architected mobile-first, targeting viewport widths from 390px to 412px (iOS standard and modern Android devices):

- **Grid Framework:** 4-column fluid mobile grid with `16px` outer canvas margins and `16px` gutters. On tablets and foldables (600px+), expand to an 8-column layout with `24px` margins.
- **Rhythm & Touch Ergonomics:** Built around an 8px base rhythm. Primary hit targets (booking triggers, driver contact button, vehicle choice selectors) adhere to a minimum height of `52px` or `56px` to permit effortless single-thumb operation while on the move.
- **Safe Area Insets:** Fixed bottom action bars account for native device home indicators (`env(safe-area-inset-bottom) + 16px`).

## Elevation & Depth

Visual hierarchy does not use murky grey dropshadows. Instead, it relies on luminous ambient backdrops, specular glass borders, and dark moss tonal container tiers.

### Depth Layers
- **Tier 0 (Map & Canvas Base):** `#142316` solid or live navigation map with custom dark moss cartography styling.
- **Tier 1 (Surface Floating Cards):** `rgba(26, 46, 28, 0.76)` background blur (`backdrop-filter: blur(24px)`), framed with a subtle border: `1px solid rgba(255, 255, 255, 0.08)`. Soft ambient underglow: `0 12px 32px -4px rgba(10, 20, 12, 0.6)`.
- **Tier 2 (Active Modules & Route Waypoints):** `#233D27` with top highlight rim `1px solid rgba(163, 230, 53, 0.25)`.
- **Tier 3 (Floating Modals & Dispatch Sliders):** `#28442D` with diffuse green glow: `0 16px 40px rgba(0, 0, 0, 0.65), 0 0 24px rgba(163, 230, 53, 0.12)`.

## Shapes

The design system embraces an ultra-rounded, soft, pebble-like shape philosophy matching the organic glass references.

- **Primary Cards and Containers:** `border-radius: 28px` (with large floating sheets utilizing `32px`).
- **Interactive Buttons & Badges:** Full pill radius (`9999px` / `rounded-full`).
- **Input Fields & Search Bars:** Pill radius (`9999px`) or minimum `20px` to mirror the pill aesthetic of search anchors and location pickers.
- **Inner Micro Elements (Thumbnails, Step Badges):** `14px` to `16px` corner radius.

## Components

### 1. Buttons
- **Primary CTA ("Réserver un camion" / Confirm Booking):**
  - *Normal:* Full pill (`border-radius: 9999px`), background gradient `linear-gradient(135deg, #A3E635 0%, #84D63E 100%)`, text `#102604` (`font-weight: 700`, `16px`), height `56px`, inner shadow `inset 0 1px 0 rgba(255, 255, 255, 0.4)`.
  - *Pressed:* Scale `0.98`, background `#84D63E`, box-shadow `0 0 20px rgba(163, 230, 53, 0.4)`.
  - *Disabled:* Background `rgba(255, 255, 255, 0.08)`, text `rgba(255, 255, 255, 0.3)`.
- **Secondary Glass Button:**
  - *Normal:* Background `rgba(35, 61, 39, 0.65)`, border `1px solid rgba(255, 255, 255, 0.15)`, text `#F1F5F0`.
  - *Hover/Pressed:* Background `rgba(40, 68, 45, 0.9)`, border-color `rgba(163, 230, 53, 0.4)`.

### 2. Vehicle Selector Chips & Status Badges
- **Status Badges (Pill Tags):**
  - Height `28px`, padding `0 12px`, radius `9999px`.
  - *En Route / Active:* Background `rgba(163, 230, 53, 0.15)`, text `#C6F24D`, border `1px solid rgba(163, 230, 53, 0.3)`.
  - *Pending / Loading:* Background `rgba(245, 158, 11, 0.15)`, text `#F6D882`, border `1px solid rgba(245, 158, 11, 0.3)`.
- **Vehicle Type Chip:**
  - Horizontal pill or pebble card showing truck icon, cargo capacity ("Jusqu'à 1.5 Tonnes"), and price estimate in `MAD`. Active state receives an outer `#A3E635` hairline outline and soft lime drop glow.

### 3. Floating Glass Cards
- Border-radius `28px`, padding `20px`. Background `rgba(22, 39, 25, 0.78)` with `backdrop-filter: blur(24px)`.
- Header area features route breadcrumbs with connecting timeline dots: Origin (e.g. "Ain Sebaâ, Casablanca") to Destination (e.g. "Gueliz, Marrakech") connected by a lime glowing connector line.

### 4. Input Fields
- Height `52px`, pill radius `9999px`, background `rgba(17, 29, 18, 0.85)`, border `1px solid rgba(61, 88, 63, 0.6)`.
- Text color `#F1F5F0`, placeholder `rgba(194, 209, 192, 0.45)`.
- Active focus state: Border color `#A3E635` with `box-shadow: 0 0 0 3px rgba(163, 230, 53, 0.2)`.

### 5. Checkboxes, Toggles & Radios
- Checkbox and radio controls use high-contrast lime fills (`#A3E635`) with dark forest checks (`#102604`).
- Toggle switches adopt pill geometry with a sliding glowing knob and glowing rail in the active state.